"""
oroscopo_payload_ai.py

Costruisce il payload AI per l'oroscopo, integrando:

- meta (dati utente / contesto)
- periodi (giornaliero, settimanale, mensile, annuale)
- kb_hooks (ganci verso la Knowledge Base)
- kb (contenuto markdown estratto da Supabase)

Gestione volume KB su 2 livelli:
1) NUMERO DI VOCI (entry KB) → dipende da tier/periodo
2) VOLUME DI TESTO (caratteri markdown) → limite per tier

⚠️ NOTA ARCHITETTURALE:
- Questo modulo NON calcola la logica dei periodi (es. decadi del mensile),
  ma accetta una struttura `oroscopo_struct["periodi"]` che può già contenere
  un mensile con sottoperiodi, ad es.:

  oroscopo_struct["periodi"]["mensile"] = {
      "label": "...",
      "date_range": {...},
      "intensita_mensile": {...},
      "sottoperiodi": [
          {
              "id": "inizio_mese",
              "label": "Inizio mese (1–10)",
              "date_range": {...},
              "intensita": {...},
              "pianeti_prevalenti": [...],
              "aspetti_rilevanti": [...],
              # (in futuro) "kb_context": {...}
          },
          ...
      ]
  }

- Qui ci limitiamo a riportare questa struttura nel payload AI,
  senza modificarla, così la parte Groq può usarla per scrivere:
  - una sintesi mensile,
  - 4 capitoli (sottoperiodi) basati sui transiti/intensità.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Set, Tuple

from .fetch_kb_from_hooks import fetch_kb_from_hooks

# =========================================================
#  Mappa periodi e policy limiti KB
# =========================================================

# Mappa chiavi italiane dei periodi -> codici interni
PERIOD_KEY_TO_CODE: Dict[str, str] = {
    "giornaliero": "daily",
    "settimanale": "weekly",
    "mensile": "monthly",
    "annuale": "yearly",
}

# Limiti per numero di voci KB, per tier e periodo.
# Ordine di priorità (in fetch_kb_from_hooks):
# transiti_pianeti → pianeti_case → segni → pianeti → case
KB_LIMITS_POLICY: Dict[str, Dict[str, Dict[str, Any]]] = {
    "free": {
        "daily": {
            "max_total_entries": 10,
            "per_section": {
                "transiti_pianeti": 3,
                "pianeti_case": 2,
                "segni": 2,
                "pianeti": 1,
                "case": 1,
            },
        },
        "weekly": {
            "max_total_entries": 14,
            "per_section": {
                "transiti_pianeti": 5,
                "pianeti_case": 3,
                "segni": 2,
                "pianeti": 1,
                "case": 1,
            },
        },
        "monthly": {
            "max_total_entries": 14,
            "per_section": {
                "transiti_pianeti": 5,
                "pianeti_case": 3,
                "segni": 2,
                "pianeti": 2,
                "case": 1,
            },
        },
        "yearly": {
            "max_total_entries": 16,
            "per_section": {
                "transiti_pianeti": 5,
                "pianeti_case": 3,
                "segni": 2,
                "pianeti": 2,
                "case": 2,
            },
        },
    },
    "premium": {
        "daily": {
            "max_total_entries": 20,
            "per_section": {
                "transiti_pianeti": 5,
                "pianeti_case": 4,
                "segni": 3,
                "pianeti": 3,
                "case": 2,
            },
        },
        "weekly": {
            "max_total_entries": 28,
            "per_section": {
                "transiti_pianeti": 8,
                "pianeti_case": 5,
                "segni": 3,
                "pianeti": 3,
                "case": 3,
            },
        },
        "monthly": {
            "max_total_entries": 36,
            "per_section": {
                "transiti_pianeti": 12,
                "pianeti_case": 6,
                "segni": 4,
                "pianeti": 3,
                "case": 3,
            },
        },
        "yearly": {
            "max_total_entries": 50,
            "per_section": {
                "transiti_pianeti": 20,
                "pianeti_case": 7,
                "segni": 4,
                "pianeti": 3,
                "case": 4,
            },
        },
    },
}

# Limite di CARATTERI per tier
KB_CHAR_LIMIT_BY_TIER: Dict[str, int] = {
    "free": 8000,
    "premium": 16000,
}

DEFAULT_TIER = "free"
DEFAULT_PERIOD_CODE = "daily"


# =========================================================
#  Funzione principale
# =========================================================

def build_oroscopo_payload_ai(
    oroscopo_struct: Dict[str, Any],
    lang: str = "it",
    period_code: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Costruisce il payload AI completo per l'oroscopo.

    Ritorna un dict del tipo:

    {
        "meta": {...},
        "tier": "free" | "premium",
        "period_code": "daily" | "weekly" | "monthly" | "yearly",
        "periodi": {...},         # copiato/adattato da oroscopo_struct["periodi"]
        "kb_hooks": {...},
        "kb": {
            "by_section": {...},
            "combined_markdown": "...",
            "lang": "it"
        }
    }

    NOTA:
    - se oroscopo_struct["periodi"]["mensile"] contiene già "sottoperiodi",
      questa struttura viene riportata tale e quale nel payload, così la
      parte Groq può generare 4 capitoli + sintesi mensile.
    """
    raw_meta = oroscopo_struct.get("meta") or {}
    tier = _normalize_tier(raw_meta.get("tier"))

    # se non passato esplicitamente, lo inferiamo dal dict periodi
    if not period_code:
        period_code = _infer_primary_period_code(oroscopo_struct)

    kb_limits = _get_kb_limits_for_context(tier, period_code)
    max_entries_per_section = kb_limits["max_entries_per_section"]
    max_total_entries = kb_limits["max_total_entries"]
    max_kb_chars = kb_limits["max_kb_chars"]

    print(
        f"[DEBUG] build_oroscopo_payload_ai: tier={tier}, period={period_code}, "
        f"transiti_limit={max_entries_per_section.get('transiti_pianeti')}"
    )

    meta = _build_meta(raw_meta, lang=lang, tier=tier)

    raw_periodi = oroscopo_struct.get("periodi") or {}
    periodi = _build_periodi_payload(raw_periodi, primary_period_code=period_code)

    kb_hooks = _build_kb_hooks(oroscopo_struct, period_code=period_code)

    if kb_hooks:
        kb_result = fetch_kb_from_hooks(
            kb_hooks,
            max_entries_per_section=max_entries_per_section,
            max_total_entries=max_total_entries,
            filter_chapters=True,
            tier=tier,
        )
    else:
        kb_result = {"by_section": {}, "combined_markdown": ""}

    combined_md_full = kb_result.get("combined_markdown", "") or ""
    combined_md_clipped = _clip_markdown(combined_md_full, max_kb_chars)

    return {
        "meta": meta,
        "tier": tier,
        "period_code": period_code,
        "periodi": periodi,
        "kb_hooks": kb_hooks,
        "kb": {
            "by_section": kb_result.get("by_section", {}),
            "combined_markdown": combined_md_clipped,
            "lang": lang,
        },
    }


# =========================================================
#  Helper vari
# =========================================================

def _normalize_tier(raw_tier: Any) -> str:
    """Normalizza il tier in {free, premium}."""
    if not raw_tier:
        return DEFAULT_TIER
    s = str(raw_tier).strip().lower()
    if s in {"premium", "paid", "pro"}:
        return "premium"
    return "free"


def _infer_primary_period_code(oroscopo_struct: Dict[str, Any]) -> str:
    """Determina il periodo principale (daily/weekly/monthly/yearly) da 'periodi'."""
    periodi = oroscopo_struct.get("periodi") or {}
    if not isinstance(periodi, dict) or not periodi:
        return DEFAULT_PERIOD_CODE

    keys = list(periodi.keys())
    if len(keys) == 1:
        k = keys[0]
        return PERIOD_KEY_TO_CODE.get(k, DEFAULT_PERIOD_CODE)

    priority = ["giornaliero", "settimanale", "mensile", "annuale"]
    for p in priority:
        if p in periodi:
            return PERIOD_KEY_TO_CODE.get(p, DEFAULT_PERIOD_CODE)

    return DEFAULT_PERIOD_CODE


def _get_kb_limits_for_context(tier: str, period_code: str) -> Dict[str, Any]:
    """Restituisce i limiti KB per (tier, periodo)."""
    tier_cfg = KB_LIMITS_POLICY.get(tier) or KB_LIMITS_POLICY[DEFAULT_TIER]
    period_cfg = tier_cfg.get(period_code) or tier_cfg.get(DEFAULT_PERIOD_CODE)

    per_section = period_cfg.get("per_section", {})
    max_total_entries = period_cfg.get("max_total_entries")
    max_kb_chars = KB_CHAR_LIMIT_BY_TIER.get(tier, KB_CHAR_LIMIT_BY_TIER[DEFAULT_TIER])

    return {
        "max_entries_per_section": per_section,
        "max_total_entries": max_total_entries,
        "max_kb_chars": max_kb_chars,
    }


def _build_meta(raw_meta: Dict[str, Any], lang: str, tier: str) -> Dict[str, Any]:
    meta = dict(raw_meta) if raw_meta else {}
    meta["lang"] = lang
    meta["tier"] = tier
    return meta


def _clip_markdown(text: str, max_chars: Optional[int]) -> str:
    """Tronca il markdown se eccede i limiti."""
    if not text:
        return ""
    if not max_chars or max_chars <= 0:
        return text
    if len(text) <= max_chars:
        return text

    clipped = text[:max_chars]
    note = (
        "\n\n---\n\n"
        "[KB TRONCATA PER LIMITI DI CONTESTO: la Knowledge Base completa è disponibile "
        "ma questa è una selezione automatica delle parti più rilevanti in base ai kb_hooks.]\n"
    )
    return clipped + note


# =========================================================
#  Costruzione PERIODI per il payload AI
# =========================================================

def _build_periodi_payload(
    raw_periodi: Dict[str, Any],
    primary_period_code: str,
) -> Dict[str, Any]:
    """
    Prepara la sezione 'periodi' del payload AI a partire da oroscopo_struct["periodi"].

    Oggi fa essenzialmente una shallow copy, MA:

    - se esiste un blocco "mensile" con struttura arricchita (es. sottoperiodi),
      viene riportato tale e quale nel payload, così il modello AI può usarlo
      per generare 4 capitoli + sintesi mensile.

    In futuro, se servirà, qui potremo:
    - normalizzare i nomi dei campi,
    - calcolare eventuali metriche derivate per l'AI,
    - agganciare direttamente la KB per sottoperiodo.
    """
    if not isinstance(raw_periodi, dict):
        return {}

    periodi: Dict[str, Any] = {}
    for key, value in raw_periodi.items():
        periodi[key] = value

    return periodi


# =========================================================
#  Costruzione kb_hooks (con filtro per periodo)
# =========================================================

def _build_kb_hooks(
    oroscopo_struct: Dict[str, Any],
    period_code: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Costruisce i kb_hooks a partire dalla struttura tecnica.

    LOGICA IMPORTANTE PER I TRANSITI:

    - Se i transiti in oroscopo_struct["transiti"] hanno un campo 'period_code'
      (es. "daily", "weekly", "monthly", "yearly"), qui filtriamo SOLO quelli
      corrispondenti al period_code richiesto.

    - Se NON troviamo alcun transito con quel period_code, facciamo fallback
      a tutti i transiti globali (per compatibilità con vecchi JSON privi di
      period_code).
    """

    existing = oroscopo_struct.get("kb_hooks")
    if isinstance(existing, dict):
        return existing

    if not period_code:
        period_code = _infer_primary_period_code(oroscopo_struct)

    case: Set[int] = set()
    pianeti: Set[str] = set()
    segni: Set[str] = set()
    pianeti_case: Set[Tuple[str, int]] = set()
    transiti_pianeti: Set[Tuple[str, str, str]] = set()

    # ---------- Tema natale: pianeti e segni ----------
    tema = oroscopo_struct.get("tema") or {}
    pianeti_decod = tema.get("pianeti_decod") or {}
    for nome_pianeta, dati in pianeti_decod.items():
        if not isinstance(dati, dict):
            continue
        nome_lower = str(nome_pianeta).lower()
        if nome_lower in {"data", "asc", "ascendente", "mc", "medium_coeli", "discendente", "cuspidi"}:
            continue
        pianeti.add(str(nome_pianeta))
        segno = dati.get("segno") or dati.get("sign")
        if segno:
            segni.add(str(segno))

    case_decod = tema.get("case_decod") or {}
    if isinstance(case_decod, dict):
        for k, dati_casa in case_decod.items():
            try:
                n_casa = int(k)
            except (TypeError, ValueError):
                continue
            case.add(n_casa)
            if isinstance(dati_casa, dict):
                segno_casa = dati_casa.get("segno") or dati_casa.get("sign")
                if segno_casa:
                    segni.add(str(segno_casa))

    # ---------- TRANSITI: filtrati per period_code ----------
    all_transits = oroscopo_struct.get("transiti") or []
    filtered: List[Dict[str, Any]] = []
    if isinstance(all_transits, list):
        for tr in all_transits:
            if not isinstance(tr, dict):
                continue
            code = tr.get("period_code")
            if code is not None and code != period_code:
                continue
            filtered.append(tr)

    if filtered:
        transits = filtered
    else:
        transits = all_transits if isinstance(all_transits, list) else []

    for tr in transits:
        if not isinstance(tr, dict):
            continue
        tp = tr.get("transit_planet")
        np = tr.get("natal_planet")
        asp = tr.get("aspect")
        if tp and np and asp:
            transiti_pianeti.add((str(tp), str(np), str(asp)))
            pianeti.add(str(tp))
            segno_tr = tr.get("segno") or tr.get("sign")
            if segno_tr:
                segni.add(str(segno_tr))

    hooks: Dict[str, Any] = {}
    if case:
        hooks["case"] = sorted(case)
    if pianeti:
        hooks["pianeti"] = sorted(pianeti)
    if segni:
        hooks["segni"] = sorted(segni)
    if pianeti_case:
        hooks["pianeti_case"] = [{"transit_planet": tp, "natal_house": h} for tp, h in sorted(pianeti_case)]
    if transiti_pianeti:
        hooks["transiti_pianeti"] = [
            {"transit_planet": tp, "natal_planet": np, "aspect": asp}
            for tp, np, asp in sorted(transiti_pianeti)
        ]
    return hooks
